<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "kenit_kientruc"); // db user
define('DB_PASSWORD', "kenit_kientruc@123"); // db password (mention your db password here)
define('DB_DATABASE', "kenit_kientruc"); // database name
define('DB_SERVER', "localhost"); // db server
?>
