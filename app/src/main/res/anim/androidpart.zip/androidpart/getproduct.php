<?php
 
/*
 * Following code will list all the products
 */
 
// array for JSON response
$response = array();
 
// include db connect class
require_once __DIR__ . '/db_connect.php';
 
// connecting to db
$db = new DB_CONNECT();
 
// get all products from products table
$result = mysql_query("SELECT *FROM ken_posts WHERE post_type = 'post'") or die(mysql_error());


// check for empty result
if (mysql_num_rows($result) > 0) {
    // looping through all results
    // products node
     

    $response["products"] = array();
    while ($row = mysql_fetch_array($result)) {
       // var_dump($row["post_content"]);
     //   echo $row["post_title"];
        // temp user array
        $product = array();
        $product["post_content"] = $row["post_content"] ;
	    $product["post_title"] = $row["post_title"];
        $product["post_date"] = $row["post_date"];
       	$product["post_name"] = $row["post_name"];
	    $product["post_link"] = $row["guid"];
        $post_id = $row["ID"];
        $getattach = mysql_query("SELECT guid FROM ken_posts WHERE post_type = 'attachment' AND post_parent = $post_id");
        $image_row = mysql_fetch_assoc($getattach);
        $product["post_attach"] =  $image_row["guid"];

        $response["post_detail"] = array();

        $details = mysql_query("SELECT * FROM ken_posts WHERE post_parent = $post_id");

        while($detail_row = mysql_fetch_array($details)) {
            $detail = array();
            $detail["post_id"] = $detail_row["ID"];
            $detail["post_date"] = $detail_row["post_date"];
            $detail["post_title"] = $detail_row["post_title"];
            $detail["post_content"] = $detail_row["post_content"];
            $detail["post_link"] = $detail_row["guid"];
          array_push($response["post_detail"],$detail);

        }
        $products["post_detail"] = $response["post_detail"];
        // push single product into final response array
        array_push($response["products"], $product);
    }
    // success
    $response["success"] = 1;
  //setLocale('vi_VN.UTF8');
    // echoing JSON response
    echo json_encode($response);
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No products found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>
